/* alert("asdad"); */
function soloLetras(e)
{
	var codigoCar=e.keyCode;
	var letra=String.fromCharCode(codigoCar);
	var caracteresPermitidos=/[A-Za-záéíóúÁÉÍÓÚ]/;
	var caracteresEspeciales=[8,9,13,14,15,32];
	if (caracteresEspeciales.indexOf(codigoCar)==-1)
		return (caracteresPermitidos.test(letra));
	else
		return true;
}

function soloNumeros(e)
{
	var codigoCar=e.keyCode;
	var letra=String.fromCharCode(codigoCar);
	var caracteresPermitidos=/[0-9]/;
	var caracteresEspeciales=[8,9,13,14,15,32];
	if (caracteresEspeciales.indexOf(codigoCar)==-1)
		return (caracteresPermitidos.test(letra));
	else
		return true;
}

function soloCi(e)
{
	var codigoCar=e.keyCode;
	var letra=String.fromCharCode(codigoCar);
	var caracteresPermitidos=/[A-Z0-9]/;
	var caracteresEspeciales=[8,9,13,14,15,32,45];
	if (caracteresEspeciales.indexOf(codigoCar)==-1)
		return (caracteresPermitidos.test(letra));
	else
		return true;
}

function soloUsuario(e)
{
	var codigoCar=e.keyCode;
	var letra=String.fromCharCode(codigoCar);
	var caracteresPermitidos=/[A-Za-z0-9]/;
	var caracteresEspeciales=[8,9,13,14,15,32,45,95];
	if (caracteresEspeciales.indexOf(codigoCar)==-1)
		return (caracteresPermitidos.test(letra));
	else
		return true;
}

